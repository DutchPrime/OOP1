package interfaces;

/**
 * This interface makes sure that the class and all subclasses have the huurIn() method
 *
 * @author Koen Lippe 500794493
 */

public interface Oproepbaar {

    void huurIn(int uren);
}
