/**
 * Description:
 *
 * @author Koen Lippe (500794493)
 *
 */

public class Vak {
    //Variables
    public String name;
    public int punten;
    public double cijfer;

    //Constructor



    //Methods
    public String getNaam(){
        return this.name;
    }

    public int getPunten(){
        return punten;
    }

    public double getCijfer(){
        return 0;
    }

    public void setCijfer(double nieuwCijfer) {
        this.cijfer = nieuwCijfer;
    }

    public int gehaaldePunten(){

    }
}
